/** Automatically generated file. DO NOT MODIFY */
package com.mwork.onepaysdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}