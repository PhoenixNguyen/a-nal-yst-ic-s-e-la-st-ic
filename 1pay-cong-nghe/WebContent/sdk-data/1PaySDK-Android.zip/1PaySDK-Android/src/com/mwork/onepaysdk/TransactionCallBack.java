
package com.mwork.onepaysdk;

public interface TransactionCallBack {
    public void callBack(boolean result, String msg);
}
