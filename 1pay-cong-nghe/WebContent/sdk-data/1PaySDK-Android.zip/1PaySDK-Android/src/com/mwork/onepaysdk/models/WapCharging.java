
package com.mwork.onepaysdk.models;

import org.json.JSONException;
import org.json.JSONObject;

public class WapCharging {
    public boolean status;

    public String back_url;

    public String error_url;

    static public WapCharging createFromJsonString(String jsonString) {
        try {
            JSONObject obj = new JSONObject(jsonString);
            WapCharging wap = new WapCharging();
            wap.back_url = obj.getString("back_url");
            wap.error_url = obj.getString("error_url");
            if (obj.get("status").equals("approved")) {
                wap.status = true;
            } else {
                wap.status = false;
            }
            return wap;
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
        }
        return null;
    }
}
