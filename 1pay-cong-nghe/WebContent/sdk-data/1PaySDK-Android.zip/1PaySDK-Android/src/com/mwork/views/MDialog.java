
package com.mwork.views;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwork.configBackGround.SetBackGround;
import com.mwork.onepaysdk.R;
import com.mwork.onepaysdk.utils.DrawableFactory;
import com.mwork.onepaysdk.utils.Utils;

public class MDialog extends Dialog {
	private TextView tvTitle;

	private TextView tvContent;

	private FrameLayout mContentFrame;

	private Button btnLeft;

	private Button btnRight;

	private Context mContext;

	private View buttonLayout;

	private ImageView imgView;

	private View mainLayout;
	
	private View vvertical;
	
	private View vhorizontal;

	private final String SDK_PREFERENCE_CONFIG = "1pay_sdk_prefs_config";

	private final String SDK_hexSolidColor = "hexSolidColor";

	private final String SDK_hexBoundColor = "hexBoundColor";

	private final String SDK_connerRadius = "connerRadius";

	private final String SDK_strokeWidth = "strokeWidth";

	private SharedPreferences mPrefsConfig;

	public MDialog(Context context, int theme) {
		super(context, theme);
		init(context);
	}

	public MDialog(Context context) {
		super(context, R.style.MDialog);
		init(context);
	}

	private void init(Context context) {
		this.mContext = context;
		this.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
		this.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.m_dialog);
		this.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,
				WindowManager.LayoutParams.WRAP_CONTENT);
		tvTitle = (TextView) findViewById(R.id.tvTitle);
		tvContent = (TextView) findViewById(R.id.tvContent);
		btnLeft = (Button) findViewById(R.id.btnLeft);
		btnRight = (Button) findViewById(R.id.btnRight);
		mContentFrame = (FrameLayout) findViewById(R.id.content_layout);
		buttonLayout = findViewById(R.id.buttonLayout);
		imgView = (ImageView) findViewById(R.id.logo);
		mainLayout = findViewById(R.id.mainLayout);
		vhorizontal = findViewById(R.id.vhorizontal);
		vvertical = findViewById(R.id.vvertical);
		
		customThem(context);
	}

	public void customThem(Context context){
		mPrefsConfig = (SharedPreferences) context.getSharedPreferences(SDK_PREFERENCE_CONFIG,
				context.MODE_PRIVATE);		
		if (mPrefsConfig.contains(SDK_hexSolidColor) && mPrefsConfig.contains(SDK_hexBoundColor) && mPrefsConfig.contains(SDK_connerRadius) && mPrefsConfig.contains(SDK_strokeWidth)) {
			String hexSolidColor = mPrefsConfig.getString(SDK_hexSolidColor, "#ffffff");
			String hexBoundColor =  mPrefsConfig.getString(SDK_hexBoundColor, "#39b54a");;
			int connerRadius = mPrefsConfig.getInt(SDK_connerRadius, 8) ;
			int strokeWidth = mPrefsConfig.getInt(SDK_strokeWidth, 2);
			Drawable dthem = DrawableFactory.makeRoundedRectangeBox( hexSolidColor, hexBoundColor,
					connerRadius, strokeWidth);
			mainLayout.setBackground(dthem);
		}else {
			loadTheme();
		}
			
	}
	
	

	private void loadTheme() {
		imgView.setImageBitmap(Utils.getBitmapFromRaw(getContext(), R.raw.logo));
		try {
			String themeString = Utils.readFileFromRaw(getContext(), R.raw.config_theme);
			JSONObject obj = new JSONObject(themeString);
			String bgColorString = obj.getString("main_background");
			if (bgColorString != null) {
				Drawable d = DrawableFactory.makeRoundedRectangeBox("#ffffff", bgColorString, 8,
						getContext().getResources().getDimensionPixelSize(R.dimen.stroke));
				if (d != null) {
					mainLayout.setBackground(d);
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public void setEnableButtons(boolean enable) {
		if (enable) {
			buttonLayout.setVisibility(View.VISIBLE);
		} else {
			buttonLayout.setVisibility(View.GONE);
		}
	}

	public void setIcon(int resId) {
		tvTitle.setCompoundDrawablesWithIntrinsicBounds(resId, 0, 0, 0);
	}

	public MDialog setContentLayout(int resId) {// can hoi
		tvContent.setVisibility(View.GONE);
		View content_layout = LayoutInflater.from(mContext).inflate(resId, null);
		return setContentLayout(content_layout);
	}

	public MDialog setContentLayout(View content_layout) {
		tvContent.setVisibility(View.GONE);
		mContentFrame.addView(content_layout, new FrameLayout.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		return this;
	}

	public void setTitle(int resId) {
		tvTitle.setText(mContext.getResources().getString(resId));
	}
	
	public void setBackGroundTitle(String colorBackground, String colorTextTitle, Typeface tf) {
		tvTitle.setBackgroundColor(Color.parseColor(colorBackground));
		tvTitle.setTextColor(Color.parseColor(colorTextTitle));
		tvTitle.setTypeface(tf);
	}
	
	public void setTitle(String title) {
		if (title != null && !title.trim().equals("")) {
			tvTitle.setText(title);
		} else {
			tvTitle.setVisibility(View.GONE);
		}
	}

	public void setContent(int resId) {
		tvContent.setText(mContext.getResources().getString(resId));
	}

	public void setContent(String content) {
		tvContent.setVisibility(View.VISIBLE);
		tvContent.setText(content);
	}
	
	public void  setColorLeftButton(String hexColorBackground, String hexColorText, String hexBound, Typeface tf) {
		try {
			vhorizontal.setVisibility(View.GONE);
			vvertical.setBackgroundColor(Color.parseColor(hexBound));
			btnLeft.setTextColor(Color.parseColor(hexColorText));
			btnLeft.setTypeface(tf);
			btnLeft.setBackground(SetBackGround.backgroundButton(hexColorBackground, 4));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public MDialog setLeftButton(String label, final android.view.View.OnClickListener listener) {
		btnLeft.setText(label);
		btnLeft.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onClick(v);
				} else {
					dismiss();
				}
			}
		});
		return this;
	}

	public MDialog setLeftButton(int label, final android.view.View.OnClickListener listener) {
		return setLeftButton(getContext().getResources().getString(label), listener);
	}
	
	public void  setColorRightButton(String hexColorBackground, String hexColorText, String hexBound, Typeface tf) {
		try {
			vhorizontal.setVisibility(View.GONE);
			vvertical.setBackgroundColor(Color.parseColor(hexBound));
			btnRight.setTextColor(Color.parseColor(hexColorText));
			btnRight.setTypeface(tf);
			btnRight.setBackground(SetBackGround.backgroundButton(hexColorBackground, 4));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public MDialog setRightButton(String label, final android.view.View.OnClickListener listener) {
		btnRight.setText(label);
		btnRight.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onClick(v);
				} else {
					dismiss();
				}
			}
		});
		return this;
	}

	public MDialog setRightButton(int label, final android.view.View.OnClickListener listener) {
		return setRightButton(getContext().getResources().getString(label), listener);
	}

	public void setLayoutPadding(int left, int top, int right, int bottom) {
		mContentFrame.setPadding(left, top, right, bottom);
	}

}
