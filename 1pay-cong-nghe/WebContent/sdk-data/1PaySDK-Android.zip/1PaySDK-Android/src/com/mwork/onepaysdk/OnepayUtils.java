
package com.mwork.onepaysdk;

import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

public class OnepayUtils {
    public static String getPriceFromCode(Context context, String shortCode) {
        char c = shortCode.charAt(1);
        int index = 0;
        try {
            index = Integer.parseInt(c + "");
        } catch (NumberFormatException e) {

        } catch (Exception e) {

        }
        String[] prices = context.getResources().getStringArray(R.array.prices);
        if (index < prices.length) {
            String price = prices[index];
            return price;
        } else {
            return prices[0];
        }
    }

    public static String getDataFormAssetFile(Context context, String path) {
        String str = null;
        AssetManager am = context.getAssets();
        try {
            InputStream is = am.open(path);
            int length = is.available();
            byte[] data = new byte[length];
            is.read(data);
            str = new String(data);
        } catch (IOException e) {
            Log.e(OnepayUtils.class.getName(), "" + e.getMessage());
        } catch (Exception e) {
            Log.e(OnepayUtils.class.getName(), "" + e.getMessage());
        }
        return str;
    }
}
