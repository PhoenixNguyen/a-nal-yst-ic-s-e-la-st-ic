package com.mwork.configBackGround;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

public class SetBackGround {
	public static GradientDrawable backgroundButton(String hexbgcolor, float cornerRadius) {
		GradientDrawable gdDefault = new GradientDrawable();
		gdDefault.setColor(Color.parseColor(hexbgcolor));
		//gdDefault.setStroke(strokeWidth, strokeColor); mau vien
		gdDefault.setCornerRadius(cornerRadius);
		return gdDefault;
	}
	
}
