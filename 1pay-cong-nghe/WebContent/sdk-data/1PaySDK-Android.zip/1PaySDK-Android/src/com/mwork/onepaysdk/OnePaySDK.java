
package com.mwork.onepaysdk;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.telephony.SmsManager;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mwork.OnePayApiLibs.APIs;
import com.mwork.OnePayApiLibs.QueryBuilder;
import com.mwork.OnePayApiLibs.Utils;
import com.mwork.configBackGround.SetBackGround;
import com.mwork.libs.networks.HttpHelper;
import com.mwork.libs.networks.NetworkUtils;
import com.mwork.onepaysdk.models.Carrier;
import com.mwork.onepaysdk.models.Charging;
import com.mwork.onepaysdk.models.Charging.StatusCode;
import com.mwork.views.MDialog;
import com.mwork.views.MDialogNotify;

public class OnePaySDK {
	private final String SDK_PREFERENCE = "1pay_sdk_prefs";

	private final String SDK_PREFERENCE_CONFIG = "1pay_sdk_prefs_config";

	private final String SDK_DATA_CONFIG = "data_config";

	private final String SDK_LANG = "sdk_lang";

	private final String SDK_hexSolidColor = "hexSolidColor";

	private final String SDK_hexBoundColor = "hexBoundColor";

	private final String SDK_connerRadius = "connerRadius";

	private final String SDK_strokeWidth = "strokeWidth";

	private final String VIETNAMESE = "vi";

	private final String ENGLISH = "en_US";

	private final String SDK_ENABLE_LANG_CHANGE = "sdk_enable_lang_change";

	private final String CALLBACK_URL = "callback://";

	private final String ERROR_URL = "error://";

	private Context context;

	private TransactionCallBack mTransactionCallBack;

	private SharedPreferences mPrefs, mPrefsConfig;

	private Charging mCharging;

	private int exchangeRateBySMS = 0, exchangeRateByIAC = 0, exchangeRateByCard = 0, exchangeRateByWAP = 0 ;

	private String exchangeUnit = "", exchangeOtherInformation="developertuandv";

	private boolean enableButtonSMS = true, enableButtonCARD = true;

	private boolean enableButtonWAP = false, enableButtonIAC = true;

	private String titleCardCharging,colorButtonCardCharging, colorTextButtonCardCharging;

	private String titleSMSCharging, colorButtonSMSCharging, colorTextButtonSMSCharging;

	private String titleIACCharging, colorButtonIACCharging, colorTextButtonIACCharging;

	private String titleWAPCharging, colorButtonWAPCharging, colorTextButtonWAPCharging;

	private String titleCancel, colorButtonCancel, colorTextButtonCancel;

	private Typeface textStyle, textStyleShowPayMent, textStyleTitleShowPayment;

	private String backgroundColorBtnShowPayment, textColorBtnShowPayment, colorBoundBtnShowPayment;

	private String backgroundColorTitle, colorTextTitleShowPayment;

	private float cornerRadiusCard, cornerRadiusSMS, cornerRadiusWAP, cornerRadiusIAC, cornerRadiusCancel;

	/**
	 * Create OnePaySDK
	 * @param context
	 * @param access_key
	 * @param secret_key
	 * @param callBack
	 */
	public OnePaySDK(Activity context) {
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		if (context == null) {
			throw new RuntimeException("Android context invalid, please pass Activity");
		}

		this.context = context;
		mPrefs = (SharedPreferences) context.getSharedPreferences(SDK_PREFERENCE,
				Context.MODE_PRIVATE);
		mPrefsConfig = (SharedPreferences) context.getSharedPreferences(SDK_PREFERENCE_CONFIG,
				context.MODE_PRIVATE);
		String language = mPrefs.getString(SDK_LANG, VIETNAMESE);
		changeLanguage(language);

		//Init charging config
		initChargingConfig();

		//Auto load new config from server
		loadConfigFromServer();

	}

	//TODO
	public void initTheme(String hexSolidColorMain, String hexBoundColorMain, int connerRadiusMain, int strokeWidthMain) {
		Editor editor = mPrefsConfig.edit();
		editor.putString(SDK_hexSolidColor, hexSolidColorMain.trim());
		editor.putString(SDK_hexBoundColor, hexBoundColorMain.trim());
		editor.putInt(SDK_connerRadius, connerRadiusMain);
		editor.putInt(SDK_strokeWidth, strokeWidthMain);
		editor.commit();
	}

	public void removeInitThem(boolean bl) {
		if (bl && mPrefsConfig.contains(SDK_hexSolidColor)) {	
			mPrefsConfig.edit().clear().commit();
		}
	}

	private void initChargingConfig() {
		String base64String = null;
		if (mPrefs.contains(SDK_DATA_CONFIG)) {
			base64String = mPrefs.getString(SDK_DATA_CONFIG, "");
		} else {
			try {
				base64String = Utils.readFileFromRaw(context, R.raw.charging_config);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (base64String != null) {
			byte[] data = Base64.decode(base64String, Base64.DEFAULT);
			String jsonString;
			try {
				jsonString = new String(data, "UTF-8");
				mCharging = Charging.createFromJsonString(jsonString);
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException("" + e.getLocalizedMessage());
			} catch (JSONException e) {
				throw new RuntimeException("" + e.getLocalizedMessage());
			} catch (Exception e) {
				throw new RuntimeException("" + e.getLocalizedMessage());
			}
		}
	}

	public void setEnableLangueChange(boolean enable) {
		mPrefs.edit().putBoolean(SDK_ENABLE_LANG_CHANGE, enable).commit();
	}

	/**
	 * Config display language for SDK
	 * @param lang - one of two values: vi for Vietnamese AND en_US for English
	 */
	public void setLanguage(String lang) {
		mPrefs.edit().putString(SDK_LANG, lang).commit();
		changeLanguage(lang);
	}

	public void setExchangeRateBySMS(int rate) {
		this.exchangeRateBySMS = rate;
	}

	public void setExchangeRateByIAC(int rate) {
		this.exchangeRateByIAC = rate;
	}

	public void setExchangeRateByCard(int rate) {
		this.exchangeRateByCard = rate;
	}

	public void setExchangeRateByWAP(int rate) {
		this.exchangeRateByWAP = rate;
	}

	public void setExchangeUnit(String unit) {
		this.exchangeUnit = unit;
	}
	public void setExchangeOtherInformation(String information) {
		this.exchangeOtherInformation = information;
	}

	public void setEnableSMSCharging(boolean enable){
		this.enableButtonSMS = enable;
	};

	public void setEnableIACCharging(boolean enable){
		this.enableButtonIAC = enable;
	};

	public void setEnableCARDCharging(boolean enable){
		this.enableButtonCARD = enable;
	};

	public void setEnableWAPCharging(boolean enable){
		this.enableButtonWAP = enable;
	};

	public void setTitleCardCharging(String title) {
		this.titleCardCharging = title;
	}

	public void setTitleSMSCharging(String title) {
		this.titleSMSCharging = title;
	}

	public void setTitleIACCharging(String title) {
		this.titleIACCharging = title;
	}

	public void setTitleWAPCharging(String title) {
		this.titleWAPCharging = title;
	}

	public void setTitleCancel(String title){
		this.titleCancel = title;
	}

	public void setColorButtonCardCharging(String hexColorBackgroundButtonCARD, String hexColorTitleButtonCARD, float cornerRadiusCARD){
		this.colorButtonCardCharging = hexColorBackgroundButtonCARD;
		this.cornerRadiusCard = cornerRadiusCARD;
		this.colorTextButtonCardCharging = hexColorTitleButtonCARD;
	}

	public void setColorButtonSMSCharging(String hexColorBackgroundButtonSMS, String hexColorTitleButtonSMS, float cornerRadiusSMS) {
		this.colorButtonSMSCharging = hexColorBackgroundButtonSMS;
		this.cornerRadiusSMS = cornerRadiusSMS;
		this.colorTextButtonSMSCharging = hexColorTitleButtonSMS;
	}

	public void setColorButtonIACCharging(String hexColorBackgroundButtonIAC, String hexColorTitleButtonIAC, float cornerRadiusIAC) {
		this.colorButtonIACCharging = hexColorBackgroundButtonIAC;
		this.cornerRadiusIAC = cornerRadiusIAC;
		this.colorTextButtonIACCharging = hexColorTitleButtonIAC;
	}

	public void setColorButtonWAPCharging(String hexColorBackgroundButtonWAP, String hexColorTitleButtonWAP, float cornerRadiusWAP) {
		this.colorButtonWAPCharging = hexColorBackgroundButtonWAP;
		this.cornerRadiusWAP = cornerRadiusWAP;
		this.colorTextButtonWAPCharging = hexColorTitleButtonWAP;
	}

	public void setColorButtonCancel(String hexColorBackgroundButtonCancel, String hexColorTitleButtonCancel, float cornerRadiusCancel){
		this.colorButtonCancel = hexColorBackgroundButtonCancel;
		this.cornerRadiusCancel = cornerRadiusCancel;
		this.colorTextButtonCancel = hexColorTitleButtonCancel;
	}

	public void setColorBackgroundTitle(String hexColorBackground, String hexColorTextTitle, Typeface typefaceTextStyleTitleShowPayment) {
		this.backgroundColorTitle = hexColorBackground;
		this.colorTextTitleShowPayment = hexColorTextTitle;
		this.textStyleTitleShowPayment = typefaceTextStyleTitleShowPayment;
	}

	public void setBackgroundColorBtnShowPayment(String hexBackgroundColor, String hexTextColor, String hexBoundColor, Typeface typefaceButtonPayment) {
		this.backgroundColorBtnShowPayment = hexBackgroundColor;
		this.textColorBtnShowPayment = hexTextColor;
		this.colorBoundBtnShowPayment = hexBoundColor;
		this.textStyleShowPayMent = typefaceButtonPayment;
	}

	public void setTextStyle(Typeface typefaceButtonpayment){
		this.textStyle = typefaceButtonpayment;
	}
	public void setTextStyleShowPayMent(Typeface tf){
		this.textStyleShowPayMent = tf;
	}
	private void loadConfigFromServer() { // doi tu private sang public de test 
		if (NetworkUtils.isNetworkAvailable(context)) {
			new LoadConfigTask().execute();
		}
	}

	public void start(TransactionCallBack callBack) {
		this.mTransactionCallBack = callBack;
		showViewOptions();
	}


	private void showViewOptions() {
		final MDialog dialog = new MDialog(this.context);
		dialog.setTitle(null);
		dialog.setEnableButtons(false);
		dialog.setCancelable(false);
		final View layout = LayoutInflater.from(context).inflate(R.layout.onpay_main_layout, null);
		dialog.setContentLayout(layout);

		//Card Charging Button
		Button btnCardCharging = (Button) layout.findViewById(R.id.btnCardCharging);
		if (colorButtonCardCharging != null && colorTextButtonCardCharging != null && cornerRadiusCard > 0) {
			btnCardCharging.setBackground(SetBackGround.backgroundButton(colorButtonCardCharging, cornerRadiusCard));
			btnCardCharging.setTextColor(Color.parseColor(colorTextButtonCardCharging));
		}
		if (titleCardCharging != null) {
			btnCardCharging.setText(titleCardCharging);
		}

		if (textStyle != null) {
			btnCardCharging.setTypeface(textStyle);
		}
		btnCardCharging.setOnClickListener(mOnChargingChooseListener);

		//SMS Charging Button
		Button btnSMSCharging = (Button) layout.findViewById(R.id.btnSMSCharging);
		if (colorButtonSMSCharging != null && colorTextButtonSMSCharging != null && cornerRadiusSMS > 0) {
			btnSMSCharging.setBackground(SetBackGround.backgroundButton(colorButtonSMSCharging, cornerRadiusSMS));
			btnSMSCharging.setTextColor(Color.parseColor(colorTextButtonSMSCharging));
		}
		if (titleSMSCharging != null) {
			btnSMSCharging.setText(titleSMSCharging);
		}

		if (textStyle != null) {
			btnSMSCharging.setTypeface(textStyle);
		}
		btnSMSCharging.setOnClickListener(mOnChargingChooseListener);

		//IAC Charging Button
		Button btnIACCharging = (Button) layout.findViewById(R.id.btnIACCharging);
		if (colorButtonIACCharging != null && colorTextButtonIACCharging != null && cornerRadiusIAC > 0) {
			btnIACCharging.setBackground(SetBackGround.backgroundButton(colorButtonIACCharging, cornerRadiusIAC));
			btnIACCharging.setTextColor(Color.parseColor(colorTextButtonIACCharging));
		}
		if (titleIACCharging != null) {
			btnIACCharging.setText(titleIACCharging);
		}

		if (textStyle != null) {
			btnIACCharging.setTypeface(textStyle);
		}
		btnIACCharging.setOnClickListener(mOnChargingChooseListener);

		//WAP Charging Button
		Button btnSwapCharging = (Button) layout.findViewById(R.id.btnSwapCharging);
		if (colorButtonWAPCharging != null && colorTextButtonWAPCharging != null && cornerRadiusWAP > 0) {
			btnSwapCharging.setBackground(SetBackGround.backgroundButton(colorButtonWAPCharging, cornerRadiusWAP));
			btnSwapCharging.setTextColor(Color.parseColor(colorTextButtonWAPCharging));
		}
		if (titleWAPCharging != null) {
			btnSwapCharging.setText(titleWAPCharging);
		}

		if (textStyle != null) {
			btnIACCharging.setTypeface(textStyle);
		}
		btnSwapCharging.setOnClickListener(mOnChargingChooseListener);

		if (mCharging.cardCharging == null || !mCharging.cardCharging.status || !enableButtonCARD) {
			btnCardCharging.setVisibility(View.GONE);
		}

		if (mCharging.smsCharging == null || !mCharging.smsCharging.status  || !enableButtonSMS) {
			btnSMSCharging.setVisibility(View.GONE);
		}

		//		final Carrier carriers = mCharging.iacCharging.getLocalCarrier(Utils.getCarrierCode(context));
		//		if (carriers != null) {	
		//			if (carriers.code.trim().equalsIgnoreCase("")||carriers.code == null) {
		//				checkButtonIAC = false; 
		//			}
		//		}else {
		//			checkButtonIAC = false;
		//		}

		if (mCharging.iacCharging == null || !mCharging.iacCharging.status  || !enableButtonIAC) {
			btnIACCharging.setVisibility(View.GONE);
		}

		if (mCharging.wapCharging == null || !mCharging.wapCharging.status || !enableButtonWAP) {
			btnSwapCharging.setVisibility(View.GONE);
		}

		Button btnCancel = (Button) layout.findViewById(R.id.btnCancel);
		if (colorButtonCancel != null && colorTextButtonCancel != null && cornerRadiusCancel > 0) {
			btnCancel.setBackground(SetBackGround.backgroundButton(colorButtonCancel, cornerRadiusCancel));
			btnCancel.setTextColor(Color.parseColor(colorTextButtonCancel));
		}
		if (titleCancel != null) {
			btnCancel.setText(titleCancel);
		}

		if (textStyle != null) {
			btnCancel.setTypeface(textStyle);
		}
		btnCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		//LANGUAGE
		RadioGroup rg = (RadioGroup) layout.findViewById(R.id.btnRG);
		boolean enableLanguageChange = mPrefs.getBoolean(SDK_ENABLE_LANG_CHANGE, true);
		if (enableLanguageChange) {
			rg.setVisibility(View.VISIBLE);
			String lang = mPrefs.getString(SDK_LANG, VIETNAMESE);
			if (lang.equals(VIETNAMESE)) {
				rg.check(R.id.btnVietnamese);
			} else {
				rg.check(R.id.btnEnglish);
			}

			rg.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					if (checkedId == R.id.btnVietnamese) {
						mPrefs.edit().putString(SDK_LANG, VIETNAMESE).commit();
						changeLanguage(VIETNAMESE);

					} else if (checkedId == R.id.btnEnglish) {
						mPrefs.edit().putString(SDK_LANG, ENGLISH).commit();
						changeLanguage(ENGLISH);
					}

					dialog.dismiss();
					showViewOptions();
				}
			});
		} else {
			rg.setVisibility(View.GONE);
		}
		dialog.show();
	}

	private void changeLanguage(String languageToLoad) {
		Locale locale = new Locale(languageToLoad);
		Locale.setDefault(locale);
		android.content.res.Configuration config = new android.content.res.Configuration();
		config.locale = locale;
		context.getResources().updateConfiguration(config,
				context.getResources().getDisplayMetrics());
	}

	private final OnClickListener mOnChargingChooseListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (v.getId() == R.id.btnCardCharging) {
				showCardCharging();
			} else if (v.getId() == R.id.btnSMSCharging) {
				showSMSCharging();
			} else if(v.getId() == R.id.btnIACCharging){
				showIACCharging();
			} else  if (v.getId() == R.id.btnSwapCharging) {
				showWapCharging();
			}
		}
	};

	// ===================== CARD CHARGING =========================

	/**
	 * Show card charging default layout
	 */
	public void showCardCharging() {
		final MDialog dialog = new MDialog(context);
		dialog.setTitle(R.string.card_charging);
		if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
			dialog.setBackGroundTitle(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
		}
		dialog.setCancelable(false);
		View contentView = LayoutInflater.from(context)
				.inflate(R.layout.layout_card_charging, null);
		dialog.setContentLayout(contentView);

		final EditText edtCardNumber = (EditText) contentView.findViewById(R.id.edtCardNumber);
		final EditText edtCardSerial = (EditText) contentView.findViewById(R.id.edtCardSerial);
		final Spinner sp = (Spinner) contentView.findViewById(R.id.spType);

		//Exchange Rate
		TextView tvPaymentNote = (TextView) contentView.findViewById(R.id.tvPaymentNote);
		if (this.exchangeRateByCard > 0) {
			tvPaymentNote.setVisibility(View.VISIBLE);
			String str = context.getString(R.string.currency_exchange_rate, "1000",
					exchangeRateByCard, exchangeUnit);
			tvPaymentNote.setText(str);
		}
		/*
		 * get type card from json 
		 * 
		 */
		String[] cardType;
		String card_type = mCharging.cardCharging.card_types.replace("[",  "").replace("]", "").replace("\"", "");
		cardType = card_type.split(",");
		ArrayList<String> typeCard = new ArrayList<String>();
		typeCard.add(context.getResources().getString(R.string.choose_card_type));
		for (String strTypeCard : cardType){
			strTypeCard.trim();
			if (!strTypeCard.equals("")) {
				typeCard.add(strTypeCard);
			}
		}
		sp.setAdapter(new ArrayAdapter<String>(context, R.layout.item_type, typeCard));
		/*
		 * get type card in xml.		
		 * sp.setAdapter(new ArrayAdapter<String>(context, R.layout.item_type, context.getResources()
				.getStringArray(R.array.card_type))); 
		 * 
		 */
		//sp.setBackgroundColor(Color.parseColor("#ff00ff"));
		sp.setOnItemSelectedListener(new OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//	((TextView)parent.getChildAt(0)).setTextColor(Color.GREEN);
				//	((TextView)parent.getChildAt(0)).setBackgroundColor(Color.parseColor("#ff00ff"));
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

			}

		});

		dialog.setLeftButton(R.string.cancel, null);
		dialog.setRightButton(R.string.send, new OnClickListener() {

			@Override
			public void onClick(View v) {
				edtCardSerial.setSelectAllOnFocus(true);
				edtCardSerial.setTextIsSelectable(true);
				edtCardNumber.setTextIsSelectable(true);
				edtCardNumber.setSelectAllOnFocus(true);
				final int pos = sp.getSelectedItemPosition();
				if (pos > 0) {
					String pin = edtCardNumber.getText().toString();
					String serial = edtCardSerial.getText().toString();
					if (pin != null && !pin.equals("") && serial != null && !serial.equals("")) {
						String type = (String) sp.getSelectedItem();
						if (NetworkUtils.isNetworkAvailableSocket()) {
							Toast.makeText(context, "pin: "+pin +" serial: "+ serial +" type: "+type, Toast.LENGTH_LONG).show();
							//startCardCharging(pin, serial, type);// strart card charging 
							dialog.dismiss();
						} else{// err network cardcharging  
							final MDialogNotify dialogErrNetWork = new MDialogNotify(context);
							dialogErrNetWork.setTitle(R.string.title_network_warning);
							dialogErrNetWork.setCancelable(false);
							if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
								dialogErrNetWork.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
							}
							dialogErrNetWork.setContent(R.string.network_warning);
							dialogErrNetWork.show();
							dialogErrNetWork.setButtonClose(new OnClickListener() {

								@Override
								public void onClick(View v) {	
									NetworkUtils.setMobileDataEnabled(context, true);
									dialogErrNetWork.dismiss();
								}
							});      

						}
					}else {// empty card
						final MDialogNotify dialogErrCard = new MDialogNotify(context);
						dialogErrCard.setTitle(R.string.card_charging);
						if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
							dialogErrCard.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
						}
						dialogErrCard.setContent(R.string.err_enter_card);
						dialogErrCard.setCancelable(false);
						dialogErrCard.show();
						dialogErrCard.setButtonClose(new OnClickListener() {

							@Override
							public void onClick(View v) {
								String pin = edtCardNumber.getText().toString().trim();
								String serial = edtCardSerial.getText().toString().trim();
								if (pin == null || pin.equalsIgnoreCase("")) {
									edtCardNumber.setFocusable(true);
									edtCardNumber.setFocusableInTouchMode(true);
									edtCardNumber.performClick();
								}else{
									edtCardNumber.setFocusable(false);
									edtCardNumber.setFocusableInTouchMode(false);
								}
								if (serial == null || serial.equalsIgnoreCase("")){
									edtCardSerial.setFocusable(true);
									edtCardSerial.setFocusableInTouchMode(true);
									edtCardSerial.performClick();
								}else {
									edtCardSerial.setFocusable(false);
									edtCardSerial.setFocusableInTouchMode(false);
								}
								dialogErrCard.dismiss();
							}
						}); 
					}
				}else {
					final MDialogNotify dialogErrCardFull = new MDialogNotify(context);
					dialogErrCardFull.setTitle(R.string.card_charging);
					if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
						dialogErrCardFull.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
					}
					dialogErrCardFull.setContent(R.string.err_enter_card);
					dialogErrCardFull.setCancelable(false);
					dialogErrCardFull.show();
					dialogErrCardFull.setButtonClose(new OnClickListener() {

						@Override
						public void onClick(View v) {
							if (pos <= 0 ) {
								sp.setFocusable(true);
								sp.setFocusableInTouchMode(true);
								sp.performClick();
							}
							dialogErrCardFull.dismiss();
						}
					}); 
				}
			}
		});

		dialog.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
		dialog.show();
	}

	/**
	 * Start card charging
	 * @param pin
	 * @param serial
	 * @param type
	 */
	public void startCardCharging(String pin, String serial, String type) {
		QueryBuilder qBuilder = new QueryBuilder(mCharging.secret_key);
		qBuilder.put("access_key", mCharging.access_key);
		qBuilder.put("type", type);
		qBuilder.put("pin", pin);
		qBuilder.put("serial", serial);
		String queryStr = qBuilder.getQueryString();
		new CardChargingTask().execute(queryStr);
	}

	private class CardChargingTask extends AsyncTask<String, Void, String> {
		ProgressDialog pd;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			if (context != null) {
				pd = new ProgressDialog(context);
				if (pd != null) {
					pd.setMessage(context.getString(R.string.charging));
					pd.show();
				}
			}
		}

		@Override
		protected String doInBackground(String... params) {
			String queryStr = params[0];
			String responseStr = HttpHelper.post(APIs.CARD_CHARGING, queryStr);
			return responseStr;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (pd != null) {
				pd.dismiss();
			}

			boolean success = false;
			String msg = "";
			if (result != null) {
				try {
					JSONObject jObject = new JSONObject(result);
					String statusCode = jObject.getString("status");
					msg = jObject.getString("description");

					if (StatusCode.SUCCESS.equals(statusCode)) {
						success = true;
					} else {
					}
				} catch (JSONException e) {
					Log.w(OnePaySDK.class.getName(), "Transaction error: " + e.getMessage());
				}
			}else {
				msg = msg + "error ";
			}
			if (mTransactionCallBack != null) {
				mTransactionCallBack.callBack(success, msg);
			}
		}
	}

	// ======================= IAC CHARGING =========================
	/**
	 * Show IAC Charging layout
	 */
	public void showIACCharging() {
		//Show dialog
		final MDialog dialog = new MDialog(context);
		dialog.setTitle(R.string.iac_charging);
		if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
			dialog.setBackGroundTitle(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
		}
		dialog.setCancelable(false);
		View contentView = LayoutInflater.from(context).inflate(R.layout.iac_charging_layout, null);
		dialog.setContentLayout(contentView);
		final TextView tvPaymentNote = (TextView) contentView.findViewById(R.id.tvPaymentNote);
		if (exchangeRateByIAC > 0) {
			tvPaymentNote.setVisibility(View.VISIBLE);
		}
		Carrier simsuport;
		String contentSimSuport = " ";
		final Spinner sp = (Spinner) contentView.findViewById(R.id.spIACNumbers);
		for (int i = 0; i < mCharging.iacCharging.carriers.size(); i++) {
			simsuport = mCharging.iacCharging.carriers.get(i);
			contentSimSuport = contentSimSuport + simsuport.name + " ";
		}		
		final Carrier carrier = mCharging.iacCharging.getLocalCarrier(Utils.getCarrierCode(context));
		final ArrayList<String> prices = new ArrayList<String>();
		prices.add(context.getString(R.string.choose_price));
		if (carrier != null) {				
			for (String str : carrier.prices) {
				str = str.trim();
				if (!str.equals("")) {
					prices.add(Integer.parseInt(str)*(carrier.unit) + " VND");
				}
			}
			sp.setAdapter(new ArrayAdapter<String>(context, R.layout.item_type, prices));
			sp.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
					//((TextView)parent.getChildAt(0)).setTextColor(Color.GREEN);//set color spriner
					String str;
					if (exchangeRateByIAC > 0) {
						if (pos == 0) {
							str = context.getString(R.string.currency_exchange_rate, "1000",
									exchangeRateByIAC, exchangeUnit);
						} else {
							int price = Integer.parseInt(prices.get(pos).replace(" VND", ""));
							str = context.getString(R.string.currency_exchange_rate, price,
									exchangeRateByIAC * price / 1000, exchangeUnit);
						}
						tvPaymentNote.setText(str);
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {

				}
			});
			dialog.setLeftButton(R.string.cancel, null);
			dialog.show();
		} else { //Show alert dialog simcard not suport
			final MDialogNotify dialogNotSuport = new MDialogNotify(context);
			dialogNotSuport.setCancelable(false);
			String simcard = context.getResources().getString(R.string.sim_card_no_support);
			dialogNotSuport.setContent(simcard + contentSimSuport);
			dialogNotSuport.setTitle(R.string.iac_charging);
			if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
				dialogNotSuport.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
			}
			dialogNotSuport.show();
			dialogNotSuport.setButtonClose(new OnClickListener() {

				@Override
				public void onClick(View v) {
					dialogNotSuport.dismiss();
				}
			});
		}
		// button send 
		dialog.setRightButton(R.string.send, new OnClickListener() {

			@Override
			public void onClick(View v) {

				int pos = sp.getSelectedItemPosition();
				if (pos > 0) {
					String priceIAC = prices.get(pos).replace(" VND", "");
					String sms = carrier.sms;
					String contentSMS = sms.replace("$PRICE", priceIAC).replace("$THONGTINKHAC",exchangeOtherInformation);
					String shortCode = mCharging.iacCharging.service_number;
					startSMSCharging(contentSMS,shortCode);// start sms charging
					//	Toast.makeText(context," sms: "+ contentSMS+" shortCode: "+ shortCode,Toast.LENGTH_LONG).show();
					dialog.dismiss();
				}else {
					final MDialogNotify dialog = new MDialogNotify(context);
					dialog.setTitle(R.string.sms_charging);
					dialog.setContent(R.string.money_sms);
					if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
						dialog.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
					}
					dialog.setCancelable(false);
					dialog.show();
					dialog.setButtonClose(new OnClickListener() {

						@Override
						public void onClick(View v) {
							dialog.dismiss();
							sp.setFocusable(true);
							sp.setFocusableInTouchMode(true);
							sp.requestFocus();
							sp.performClick();
						}
					}); 
				}

			}
		});

	}


	// ======================= SMS CHARGING =========================
	/**
	 * Show SMS Charging layout
	 */
	public void showSMSCharging() {
		final String[] shortCodes;
		String priceString = mCharging.smsCharging.shortCodes.replace("[", "");
		priceString = priceString.replace("]", "");
		priceString = priceString.replace("\"", "");
		shortCodes = priceString.split(",");

		final ArrayList<String> prices = new ArrayList<String>();
		prices.add(context.getString(R.string.choose_price));
		for (String str : shortCodes) {
			str = str.trim();
			if (!str.equals("")) {
				prices.add(OnepayUtils.getPriceFromCode(context, str) + " VND");
			}
		}

		//Show dialog
		final MDialog dialog = new MDialog(context);
		dialog.setTitle(R.string.sms_charging);
		if (backgroundColorBtnShowPayment != null && textColorBtnShowPayment != null && colorBoundBtnShowPayment != null && textStyleShowPayMent != null) {
			dialog.setColorRightButton(backgroundColorBtnShowPayment, textColorBtnShowPayment, colorBoundBtnShowPayment, textStyleShowPayMent);
		}
		if (backgroundColorBtnShowPayment != null && textColorBtnShowPayment != null && colorBoundBtnShowPayment != null && textStyleShowPayMent != null) {
			dialog.setColorLeftButton(backgroundColorBtnShowPayment, textColorBtnShowPayment, colorBoundBtnShowPayment, textStyleShowPayMent);
		}
		if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
			dialog.setBackGroundTitle(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
		}
		dialog.setCancelable(false);
		View contentView = LayoutInflater.from(context).inflate(R.layout.sms_charging_layout, null);
		dialog.setContentLayout(contentView);

		final TextView tvPaymentNote = (TextView) contentView.findViewById(R.id.tvPaymentNote);
		if (exchangeRateBySMS > 0) {
			tvPaymentNote.setVisibility(View.VISIBLE);
		}

		final Spinner sp = (Spinner) contentView.findViewById(R.id.spSMSNumbers);
		sp.setAdapter(new ArrayAdapter<String>(context, R.layout.item_type, prices));
		sp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
				String str;
				//((TextView) parent.getChildAt(0)).setTextColor(Color.BLUE);// set color spriner
				if (exchangeRateBySMS > 0) {
					if (pos == 0) {
						str = context.getString(R.string.currency_exchange_rate, "1000",
								exchangeRateBySMS, exchangeUnit);
					} else {
						int price = Integer.parseInt(prices.get(pos).replace(" VND", ""));
						str = context.getString(R.string.currency_exchange_rate, price,
								exchangeRateBySMS * price / 1000, exchangeUnit);
					}
					tvPaymentNote.setText(str);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});
		dialog.setRightButton(R.string.send, new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = sp.getSelectedItemPosition();
				if (pos > 0) {
					String shortCode = shortCodes[pos - 1];
					startSMSCharging(mCharging.smsCharging.command+" "+UUID.randomUUID().toString(), shortCode);// start sms charging
					//					Toast.makeText(context, "content: "+ mCharging.smsCharging.command +" trans_id: "
					//							+ UUID.randomUUID().toString()+ " shortCode: "+shortCode, Toast.LENGTH_LONG).show();
					dialog.dismiss();
				}else {
					final MDialogNotify dialog = new MDialogNotify(context);
					dialog.setTitle(R.string.sms_charging);
					dialog.setContent(R.string.money_sms);
					if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
						dialog.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
					}
					dialog.setCancelable(false);
					dialog.show();
					dialog.setButtonClose(new OnClickListener() {

						@Override
						public void onClick(View v) {
							dialog.dismiss();
							sp.setFocusable(true);
							sp.setFocusableInTouchMode(true);
							sp.requestFocus();
							sp.performClick();
						}
					}); 
				}
			}
		});
		dialog.setLeftButton(R.string.cancel, null);
		dialog.show();
	}

	private void sendSMSWithApp(Context context, String content, String phoneNumber) {
		Intent sendIntent = new Intent(Intent.ACTION_VIEW);
		sendIntent.putExtra("sms_body", content);
		sendIntent.putExtra("address", phoneNumber);
		sendIntent.setType("vnd.android-dir/mms-sms");
		context.startActivity(sendIntent);
	}

	public void startSMSCharging(String content, String phoneNumber) {
		SmsManager smsManager = SmsManager.getDefault();
		smsManager.sendTextMessage(phoneNumber, null, content, null, null);
		final MDialogNotify dialog = new MDialogNotify(context);
		dialog.setTitle(R.string.sms_charging);
		dialog.setContent(R.string.sms_sent);
		if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
			dialog.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
		}
		dialog.setCancelable(false);
		dialog.show();
		dialog.setButtonClose(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});      
	}

	//====================== SUB CHARGING ===========================
	private void subscriptionCharging(Context context) {
		this.context = context;
		new SubcriptionChargingTask().execute();
	}

	private String subscriptionCharging(String msisdn, String username, String service_id) {
		QueryBuilder qBuilder = new QueryBuilder(this.mCharging.secret_key);
		qBuilder.put("access_key", "my_key");
		qBuilder.put("msisdn", "my_mobile_number");
		qBuilder.put("provider", "3");
		qBuilder.put("refcode", "");
		qBuilder.put("service_id", "my_service_id");
		qBuilder.put("username", "dangnv");
		String queryStr = qBuilder.getQueryString();
		return HttpHelper.getData(APIs.SUBSCRIPTION_CHARGING + "?" + queryStr);
	}

	private class SubcriptionChargingTask extends AsyncTask<Void, Void, String> {
		ProgressDialog pd;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pd = new ProgressDialog(context);
			pd.setMessage(context.getString(R.string.charging));
			pd.show();
		}

		@Override
		protected String doInBackground(Void... params) {
			return subscriptionCharging("afdrer3232dfdf", "dangnv", "adfdf33");
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (pd != null) {
				pd.dismiss();
			}
			Log.e(OnePaySDK.class.getName(), "subcription charging: " + result);
		}
	}

	//========================== WAP CHARGING =============================
	public void showWapCharging() {
		final MDialog dialog = new MDialog(context);
		dialog.setTitle(R.string.swap_charging);
		dialog.setCancelable(false);
		View contentView = LayoutInflater.from(context)
				.inflate(R.layout.wap_charging_layout1, null);
		dialog.setContentLayout(contentView);

		final String[] prices = context.getResources().getStringArray(R.array.prices);
		final ArrayList<String> arrayPrices = new ArrayList<String>();
		arrayPrices.add(context.getString(R.string.choose_price));
		for (String str : prices) {
			if (!str.trim().equals("")) {
				arrayPrices.add(str + " VND");
			}
		}

		final TextView tvPaymentNote = (TextView) contentView.findViewById(R.id.tvPaymentNote);
		if (this.exchangeRateByWAP > 0) {
			tvPaymentNote.setVisibility(View.VISIBLE);
		}

		final Spinner sp = (Spinner) contentView.findViewById(R.id.spPrices);
		sp.setAdapter(new ArrayAdapter<String>(context, R.layout.item_type, arrayPrices));
		sp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
				String str;
				//	((TextView)parent.getChildAt(0)).setTextColor(Color.BLUE);
				if (exchangeRateByWAP > 0) {
					if (pos == 0) {
						str = context.getString(R.string.currency_exchange_rate, "1000",
								exchangeRateByWAP, exchangeUnit);
					} else {
						int price = Integer.parseInt(arrayPrices.get(pos).replace(" VND", ""));
						str = context.getString(R.string.currency_exchange_rate, price,
								exchangeRateByWAP * price / 1000, exchangeUnit);
					}
					tvPaymentNote.setText(str);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});
		dialog.setLeftButton(R.string.cancel, null);
		dialog.setRightButton(R.string.send, new OnClickListener() {

			@Override
			public void onClick(View v) {
				int pos = sp.getSelectedItemPosition();
				if (pos > 0) {
					if (NetworkUtils.isConnectedMobile(context)) {
						startWapCharging(prices[pos - 1]);
						dialog.dismiss();
					}else{
						final MDialogNotify dialogWap = new MDialogNotify(context);
						dialogWap.setTitle(R.string.swap_charging);
						dialogWap.setContent(R.string.network_warning_type_mobile);
						if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
							dialogWap.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
						}
						dialogWap.setCancelable(false);
						dialogWap.show();
						dialogWap.setButtonClose(new OnClickListener() {

							@Override
							public void onClick(View v) {
								NetworkUtils.setMobileDataEnabled(context, true);
								dialogWap.dismiss();							
							}
						});
					}

				}else{
					final MDialogNotify dialogWap = new MDialogNotify(context);
					dialogWap.setTitle(R.string.swap_charging);
					dialogWap.setContent(R.string.money_sms);
					if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
						dialogWap.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
					}
					dialogWap.setCancelable(false);
					dialogWap.show();
					dialogWap.setButtonClose(new OnClickListener() {

						@Override
						public void onClick(View v) {
							dialogWap.dismiss();
							sp.setFocusable(true);
							sp.setFocusableInTouchMode(true);
							sp.performClick();
						}
					});
				} 
			}
		});

		dialog.show();
	}

	/**
	 * Start wap charging
	 * @param price
	 */
	public void startWapCharging(final String price) {
		QueryBuilder qBuilder = new QueryBuilder(mCharging.secret_key);
		qBuilder.put("access_key", mCharging.access_key);
		qBuilder.put("action", "charging");
		qBuilder.put("backurl", CALLBACK_URL);
		qBuilder.put("cid", "app_id: " + mCharging.app_id);
		qBuilder.put("cinfo", "app_code:" + mCharging.app_code);
		qBuilder.put("errurl", ERROR_URL);
		qBuilder.put("price", price);
		qBuilder.put("transid", UUID.randomUUID().toString());

		String queryStr = qBuilder.getQueryString();

		//		String requestUrl ="http://api.1pay.vn/wap-charging/charging?" + queryStr;
		String requestUrl =APIs.WAP_CHARGING+"charging?" + queryStr;

		final MDialog dialog = new MDialog(context);
		dialog.setCanceledOnTouchOutside(false);
		if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
			dialog.setBackGroundTitle(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
		}
		dialog.setEnableButtons(false);
		dialog.setCancelable(false);
		dialog.setTitle(R.string.swap_charging);
		final View contentView = LayoutInflater.from(context)
				.inflate(R.layout.wap_charging_layout2, null);
		dialog.setContentLayout(contentView);

		final ProgressBar pb = (ProgressBar) contentView.findViewById(R.id.progressBar);
		final WebView webView = (WebView) contentView.findViewById(R.id.webView);
		webView.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				pb.setVisibility(View.VISIBLE);
			}
			// webview http status 404.
			@Override 
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				try {
					webView.stopLoading();
				} catch (Exception e) {
				}
				try {
					webView.clearView();
				} catch (Exception e) {
				}
				if (webView.canGoBack()) {
					webView.goBack();
				}
				if (contentView != null) {
					ViewGroup vg = (ViewGroup) contentView.getParent();
					vg.removeView(contentView);
				}
				dialog.dismiss();// close dialog webview 
				final MDialogNotify dialog = new MDialogNotify(context);			
				dialog.setTitle(R.string.swap_charging);
				dialog.setContent(description);
				if (backgroundColorTitle != null && colorTextTitleShowPayment != null && textStyleTitleShowPayment != null) {
					dialog.setBackGroundTitleMDialog(backgroundColorTitle, colorTextTitleShowPayment, textStyleTitleShowPayment);
				}
				dialog.show();
				dialog.setButtonClose(new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();// close dialog toast notification.
					}
				});
				super.onReceivedError(view, errorCode, description, failingUrl);
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				List<NameValuePair> parameters = null;

				try {
					parameters = URLEncodedUtils.parse(new URI(url), "UTF-8");
				} catch (URISyntaxException e) {
					e.printStackTrace();
				}

				if (parameters != null) {
					if (url.startsWith(ERROR_URL)) { //Error
						for (NameValuePair nameValuePair : parameters) {
							String keyName = nameValuePair.getName();
							if (keyName.equals("error_message")) {
								String error_msg = nameValuePair.getValue();
								mTransactionCallBack.callBack(false, error_msg);
								dialog.dismiss();
							}
						}
					} else if (url.startsWith(CALLBACK_URL)) { //Success
						for (NameValuePair nameValuePair : parameters) {
							String keyName = nameValuePair.getName();
							if (keyName.equals("debit_status")) {
								String value = nameValuePair.getValue();
								if (value.equals("0")) {
									mTransactionCallBack.callBack(false,
											context.getString(R.string.tran_failed));
									dialog.dismiss();
								} else if (value.equals("1")) {
									mTransactionCallBack.callBack(true,
											context.getString(R.string.tran_success));
									dialog.dismiss();
								}
							}
						}
					} else if (url.contains("/cancel")) {
						dialog.dismiss();
					}
				}

				return super.shouldOverrideUrlLoading(view, url);
			}


			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				pb.setVisibility(View.GONE);
			}
		});
		webView.getSettings().setJavaScriptEnabled(true); 

		// Other webview options

		webView.getSettings().setLoadWithOverviewMode(true);
		webView.getSettings().setUseWideViewPort(true);
		webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
		webView.setScrollbarFadingEnabled(false);
		webView.getSettings().setBuiltInZoomControls(true);

		View btnCancel = contentView.findViewById(R.id.btnCancel);
		btnCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				webView.stopLoading();
				dialog.dismiss();
			}
		});

		dialog.setLeftButton(R.string.cancel, new OnClickListener() {

			@Override
			public void onClick(View v) {
				webView.stopLoading();
			}
		});

		dialog.setRightButton(null, null);

		dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

			@Override
			public void onDismiss(DialogInterface dialog) {
				webView.stopLoading();
			}
		});

		webView.loadUrl(requestUrl);
		dialog.show();
	}
	private class LoadConfigTask extends AsyncTask<Void, Void, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(Void... params) {
			try {
				String url = String.format(
						"http://api.1pay.vn/smsgw/application/charging/config?access_key=%s",//can hoi
						mCharging.access_key);
				String responseString = HttpHelper.getData(url);
				return responseString;
			} catch (Exception e) {
				Log.e(OnePaySDK.class.getName(), "" + e.getMessage());
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (result != null && !result.trim().equalsIgnoreCase("")) {
				parseData(result);
			}
		}
	}

	private void parseData(String base64String) {
		try {
			byte[] data = Base64.decode(base64String, Base64.DEFAULT);
			String jsonString = new String(data, "UTF-8");
			mCharging = Charging.createFromJsonString(jsonString);
			if (mCharging != null) { //success
				mPrefs.edit().putString(SDK_DATA_CONFIG, base64String).commit(); //Save lastest configuration data to local
			}
		} catch (IllegalArgumentException e) {
			Log.e(OnePaySDK.class.getName(), "" + e.getMessage());
		} catch (JSONException e) {
			Log.e(OnePaySDK.class.getName(), "" + e.getMessage());
		} catch (Exception e) {
			Log.e(OnePaySDK.class.getName(), "" + e.getMessage());
		}
	}
}
