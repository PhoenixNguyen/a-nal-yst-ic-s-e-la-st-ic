
package com.mwork.views;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwork.onepaysdk.R;
import com.mwork.onepaysdk.utils.DrawableFactory;
import com.mwork.onepaysdk.utils.Utils;

public class MDialogWeb extends Dialog {
    private TextView tvTitle;

    private TextView tvContent;

    private FrameLayout mContentFrame;

    private Button btnLeft;

    private Button btnRight;

    private Context mContext;

    private View buttonLayout;

    private ImageView imgView;

    private View mainLayout;

    private ImageView imgViewClose;
    
    public MDialogWeb(Context context, int theme) {
        super(context, theme);
        init(context);
    }

    public MDialogWeb(Context context) {
        super(context, R.style.MDialog);
        init(context);
    }

    private void init(Context context) {
        this.mContext = context;
        this.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
        this.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.m_dialog_web);
        this.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvContent = (TextView) findViewById(R.id.tvContent);
        btnLeft = (Button) findViewById(R.id.btnLeft);
        btnRight = (Button) findViewById(R.id.btnRight);
        imgViewClose = (ImageView) findViewById(R.id.btnClose);
        mContentFrame = (FrameLayout) findViewById(R.id.content_layout);
        buttonLayout = findViewById(R.id.buttonLayout);

        imgView = (ImageView) findViewById(R.id.logo);
        mainLayout = findViewById(R.id.mainLayout);

        loadTheme();
    }

    private void loadTheme() {
        imgView.setImageBitmap(Utils.getBitmapFromRaw(getContext(), R.raw.logo));
        try {
            String themeString = Utils.readFileFromRaw(getContext(), R.raw.config_theme);
            JSONObject obj = new JSONObject(themeString);
            String bgColorString = obj.getString("main_background");
            if (bgColorString != null) {
                Drawable d = DrawableFactory.makeRoundedRectangeBox("#ffffff", bgColorString, 8,
                        getContext().getResources().getDimensionPixelSize(R.dimen.stroke));
                if (d != null) {
                    mainLayout.setBackground(d);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void setEnableButtons(boolean enable) {
        if (enable) {
            buttonLayout.setVisibility(View.VISIBLE);
        } else {
            buttonLayout.setVisibility(View.GONE);
        }
    }

    public void setIcon(int resId) {
        tvTitle.setCompoundDrawablesWithIntrinsicBounds(resId, 0, 0, 0);
    }

    public MDialogWeb setContentLayout(int resId) {// can hoi
        tvContent.setVisibility(View.GONE);
        View content_layout = LayoutInflater.from(mContext).inflate(resId, null);
        return setContentLayout(content_layout);
    }

    public MDialogWeb setContentLayout(View content_layout) {
        tvContent.setVisibility(View.GONE);
        mContentFrame.addView(content_layout, new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        return this;
    }

    public void setTitle(int resId) {
        tvTitle.setText(mContext.getResources().getString(resId));
    }

    public void setTitle(String title) {
        if (title != null && !title.trim().equals("")) {
            tvTitle.setText(title);
        } else {
            tvTitle.setVisibility(View.GONE);
        }
    }

    public void setContent(int resId) {
        tvContent.setText(mContext.getResources().getString(resId));
    }

    public void setContent(String content) {
        tvContent.setVisibility(View.VISIBLE);
        tvContent.setText(content);
    }

    public MDialogWeb setLeftButton(String label, final android.view.View.OnClickListener listener) {
        btnLeft.setText(label);
        btnLeft.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onClick(v);
                } else {
                    dismiss();
                }
            }
        });
        return this;
    }

    public MDialogWeb setLeftButton(int label, final android.view.View.OnClickListener listener) {
        return setLeftButton(getContext().getResources().getString(label), listener);
    }

    public MDialogWeb setRightButton(String label, final android.view.View.OnClickListener listener) {
        btnRight.setText(label);
        btnRight.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onClick(v);
                } else {
                    dismiss();
                }
            }
        });
        return this;
    }

    public MDialogWeb setRightButton(int label, final android.view.View.OnClickListener listener) {
        return setRightButton(getContext().getResources().getString(label), listener);
    }

    public void setLayoutPadding(int left, int top, int right, int bottom) {
        mContentFrame.setPadding(left, top, right, bottom);
    }
    
    public MDialogWeb setButtonClose(final android.view.View.OnClickListener listener) {
		imgViewClose.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onClick(v);
				} else {
					dismiss();
				}
			}
		});
		return this;
	}

}
