
package com.mwork.views;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwork.onepaysdk.R;
import com.mwork.onepaysdk.utils.DrawableFactory;
import com.mwork.onepaysdk.utils.Utils;

public class MDialogNotify extends Dialog {
	private TextView tvTitle;

	private TextView tvContent;

	private Context mContext;

	private ImageView imgView;

	private ImageView imgViewClose;

	private View mainLayout;

	public MDialogNotify(Context context, int theme) {
		super(context, theme);
		init(context);
	}

	public MDialogNotify(Context context) {
		super(context, R.style.MDialog);
		init(context);
	}

	private void init(Context context) {
		this.mContext = context;
		this.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
		this.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.m_dialog_notify);
		this.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,
				WindowManager.LayoutParams.WRAP_CONTENT);
		tvTitle = (TextView) findViewById(R.id.tvTitle);
		tvContent = (TextView) findViewById(R.id.tvContent);
		imgView = (ImageView) findViewById(R.id.logo);
		imgViewClose = (ImageView) findViewById(R.id.btnClose);
		mainLayout = findViewById(R.id.main_layout);

		loadTheme();
	}

	private void loadTheme() {
		imgView.setImageBitmap(Utils.getBitmapFromRaw(getContext(), R.raw.logo));
		try {
			String themeString = Utils.readFileFromRaw(getContext(), R.raw.config_theme);
			JSONObject obj = new JSONObject(themeString);
			String bgColorString = obj.getString("main_background");
			if (bgColorString != null) {
				Drawable d = DrawableFactory.makeRoundedRectangeBox("#ffffff", bgColorString, 8,
						getContext().getResources().getDimensionPixelSize(R.dimen.stroke));
				if (d != null) {
					mainLayout.setBackground(d);
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public void setIcon(int resId) {
		tvTitle.setCompoundDrawablesWithIntrinsicBounds(resId, 0, 0, 0);
	}

	public void setTitle(int resId) {
		tvTitle.setText(mContext.getResources().getString(resId));
	}

	public void setTitle(String title) {
		if (title != null && !title.trim().equals("")) {
			tvTitle.setText(title);
		} else {
			tvTitle.setVisibility(View.GONE);
		}
	}
	
	public void setBackGroundTitleMDialog(String colorBackground, String colorTextTitle, Typeface tf) {
		tvTitle.setBackgroundColor(Color.parseColor(colorBackground));
		tvTitle.setTextColor(Color.parseColor(colorTextTitle));
		tvTitle.setTypeface(tf);
	}

	public void setContent(int resId) {
		tvContent.setText(mContext.getResources().getString(resId));
	}

	public void setContent(String content) {
		tvContent.setVisibility(View.VISIBLE);
		tvContent.setText(content);
	}
	
	public MDialogNotify setButtonClose(final android.view.View.OnClickListener listener) {
		imgViewClose.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onClick(v);
				} else {
					dismiss();
				}
			}
		});
		return this;
	}
}
