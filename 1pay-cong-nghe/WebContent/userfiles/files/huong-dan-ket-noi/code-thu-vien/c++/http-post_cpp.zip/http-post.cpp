//============================================================================
// Name        : http-post.cpp
// Author      : 1PAY
// Version     : 1.0
// Copyright   : (c) 2014
// Description : C++, Ansi-style
//============================================================================

#include <iostream>
#include <sstream>
#include <string>
#include <curl/curl.h>

using namespace std;

static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

string sendHttpRequest(string urlRequest,string params){

   std::string readBuffer;
  
   CURL *curl;
   CURLcode res;
   curl_global_init(CURL_GLOBAL_ALL);
   curl = curl_easy_init();
   
   if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL,urlRequest.c_str());
          /* specify the POST data */
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS,params.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);       
   }

   curl_global_cleanup();
   std::cout << readBuffer << std::endl;

   return readBuffer;	
}
