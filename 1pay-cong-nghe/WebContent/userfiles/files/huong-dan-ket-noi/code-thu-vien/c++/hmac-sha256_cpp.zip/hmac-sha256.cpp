//============================================================================
// Name        : hmac-sha256.cpp
// Author      : 1PAY
// Version     : 1.0
// Copyright   : (c) 2014
// Description : C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
#include <openssl/hmac.h>
#include <cstring>
using namespace std;

string hmac(string secret, string msg)
{
    char key[secret.length()];
    strcpy(key,secret.c_str());
    char  data[msg.length()];
    strcpy(data,msg.c_str());
    unsigned char* result;
    unsigned int len = 64;
    result = (unsigned char*)malloc(sizeof(char) * len);
    HMAC_CTX ctx;
    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, key, strlen(key), EVP_sha256(), NULL);
    HMAC_Update(&ctx, (unsigned char*)&data, strlen(data));
    HMAC_Final(&ctx, result, &len);
    HMAC_CTX_cleanup(&ctx);

    char mdString[64];
    for(int i = 0; i < len; i++)
         sprintf(&mdString[i*2], "%02x", (unsigned int)result[i]);

  //  printf("HMAC digest: %s\n", mdString);
  //  printf("\n");

     return  mdString;
}
